package com.ensta.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.model.Reservation;
import com.ensta.rentmanager.model.Vehicle;
import com.ensta.rentmanager.persistence.ConnectionManager;

public class VehicleDao {
	
	private static VehicleDao instance = null;
	private static VehicleDao instanceTest = null;
	private boolean test;
	
	private VehicleDao(boolean test) {
		this.test = test;
	}
	
	private VehicleDao() {}
	
	public static VehicleDao getInstance(boolean test) {
		if(test){
			if(instanceTest == null) {
				instanceTest = new VehicleDao(true);
			}
			return instanceTest;
		}else {
			if (instance == null) {
				instance = new VehicleDao(false);
			}
			return instance;
		}
	}
	
	private static final String CREATE_VEHICLE_QUERY = "INSERT INTO Vehicle(constructeur,modele, nb_places) VALUES(?, ?, ?);";
	private static final String DELETE_VEHICLE_QUERY = "DELETE FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLE_QUERY = "SELECT id, constructeur,modele, nb_places FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLES_QUERY = "SELECT id, constructeur,modele, nb_places FROM Vehicle;";
	private static final String UPDATE_VEHICLES_QUERY = "UPDATE Vehicle SET constructeur = ?,modele = ?, nb_places = ? WHERE id =?;";

	public long create(Vehicle vehicle) throws DaoException {
		
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(CREATE_VEHICLE_QUERY); 
				){			
			statement.setString(1, vehicle.getConstructeur());
			statement.setString(2, vehicle.getModele());
			statement.setInt(3, vehicle.getNb_places());
			
			long result = statement.executeUpdate(); 
			
			return result;
			
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la création : " + e.getMessage());
		}
		
	}
	
	public long update(int id, Vehicle vehicle) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(UPDATE_VEHICLES_QUERY);) {
			statement.setString(1, vehicle.getConstructeur());
			statement.setString(2, vehicle.getModele());
			statement.setInt(3, vehicle.getNb_places());
			statement.setInt(4, id);

			long result = statement.executeUpdate();
			return result;
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la modification : " + e.getMessage());
		}

	}

	public long delete(int id) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(DELETE_VEHICLE_QUERY); 
				){			
			statement.setInt(1,id);
			
			long result = statement.executeUpdate();
			return result;
			
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la création : " + e.getMessage());
		}
		
	}

	public Optional<Vehicle> findById(int id) {
			Vehicle v = new Vehicle();
		
		Optional<Vehicle> optClient = Optional.of(v);
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(FIND_VEHICLE_QUERY);) {
			
			statement.setInt(1, id);
			ResultSet resultSet2 = statement.executeQuery();
		
			
			while(resultSet2.next()) {
				
				v.setId(id);
				
				v.setConstructeur(resultSet2.getString(2));
				v.setModele(resultSet2.getString(3));
				v.setNb_places(resultSet2.getInt(4));			
				
			}
			
		} catch(SQLException e) {
			
			return Optional.empty();
			
		}
		return optClient;
	}

	public List<Vehicle> findAll() throws DaoException {
		
		List<Vehicle> resultList= new ArrayList<>();
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(FIND_VEHICLES_QUERY); ){
			
			ResultSet resultSet = statement.executeQuery();
			
			
			while(resultSet.next()) {
				
				Vehicle vehicule = new Vehicle(
						resultSet.getInt(1),
						resultSet.getString(2),
						resultSet.getString(3),
						resultSet.getInt(4)
						);

				resultList.add(vehicule);
			}
			

		}catch (SQLException e) {
			throw new DaoException("Erreur lors de la création : " + e.getMessage());
		}
		return resultList;
		
	}
	
	public static void main (String... args) {
		VehicleDao dao = VehicleDao.getInstance(false);
		
		try {
			List<Vehicle> list= dao.findAll();
			for(Vehicle v :  list) {
				System.out.println(v);
			}
			
			
			
		}catch (DaoException e ) {
				System.out.println("Erreur lors du Select" + e.getMessage());
		}
		
		
			Optional<Vehicle> optVehicle = dao.findById(1);
			if(optVehicle.isPresent()) {
				Vehicle v=optVehicle.get();
				System.out.println(v);
			} 
			else {
				System.out.println("Erreur lors du select du vehicule");
			}
		
	
		}
		
	}



