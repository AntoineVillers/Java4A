package com.ensta.rentmanager.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.dao.ClientDao;


public class ClientService {
	private ClientDao clientdao;
	private boolean test;

	public static ClientService instance;
	private static ClientService instanceTest = null;

	private ClientService() {
		this.clientdao = ClientDao.getInstance(false);
	}

	private ClientService(boolean test) {
		this.clientdao = ClientDao.getInstance(test);
		this.test = test;
	}

	public static ClientService getInstance(boolean test) {
		if(test){
			if(instanceTest == null) {
				instanceTest = new ClientService(true);
			}
			return instanceTest;
		}else {
			if (instance == null) {
				instance = new ClientService(false);

			}
			return instance;
		}
	}
	
	public long create(Client client) throws ServiceException {
		
		long age = ChronoUnit.YEARS.between(client.getNaissance().toLocalDate(), LocalDate.now());
		if (age < 18) {
			throw new ServiceException("Le client doit avoir au moins 18 ans. ");
		}
		if (client.getNom().equals("") == true) {
			throw new ServiceException("Le champ Nom est vide.");
		}
		if (client.getPrenom().equals("") == true) {
			throw new ServiceException("Le champ Prénom est vide.");
		}
		if (client.getEmail().equals("") == true) {
			throw new ServiceException("Le champ Email est vide.");
		}
		if (client.getNaissance().equals("") == true) {
			throw new ServiceException("Veuillez renseigner une date de naissance. ");
		}
		if (client.getEmail().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$") == false) {
			throw new ServiceException("Veuillez saisir un email valide. ");
		}

		if (client.getNom().length() < 3) {
			throw new ServiceException("Le champ Nom doit contenir au moins 3 caractères.");
		}

		if (client.getPrenom().length() < 3) {
			throw new ServiceException("Le champ Prénom doit contenir au moins 3 caractères.");
		}

		for (int i = 0; i < this.findAll().size(); i++) {
			Client monclient = new Client();
			monclient = this.findAll().get(i);
			if (monclient.getEmail().equals(client.getEmail())) {
					throw new ServiceException("L'email renseigné est déjà utilisé pour un autre utilisateur.");
			}
		}

		try {
			return clientdao.create(client);
			
		} catch(DaoException e){
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	public long update(int id, Client client) throws ServiceException {

		long age = ChronoUnit.YEARS.between(client.getNaissance().toLocalDate(), LocalDate.now());
		if (age < 18) {
			throw new ServiceException("Le client doit avoir au moins 18 ans. ");
		}
		if (client.getNom().equals("") == true) {
			throw new ServiceException("Le champ Nom est vide.");
		}
		if (client.getPrenom().equals("") == true) {
			throw new ServiceException("Le champ Prénom est vide.");
		}
		if (client.getEmail().equals("") == true) {
			throw new ServiceException("Le champ Email est vide.");
		}
		if (client.getNaissance().equals("") == true) {
			throw new ServiceException("Veuillez renseigner une date de naissance. ");
		}
		if (client.getEmail().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$") == false) {
			throw new ServiceException("Veuillez saisir un email valide. ");
		}

		if (client.getNom().length() < 3) {
			throw new ServiceException("Le champ Nom doit contenir au moins 3 caractères.");
		}

		if (client.getPrenom().length() < 3) {
			throw new ServiceException("Le champ Prénom doit contenir au moins 3 caractères.");
		}

		for (int i = 0; i < this.findAll().size(); i++) {
			Client monclient = new Client();
			monclient = this.findAll().get(i);
			if (monclient.getEmail().equals(client.getEmail())) {
				if (id != monclient.getId()) {
					throw new ServiceException("L'email renseigné est déjà utilisé pour un autre utilisateur.");
				}
			}
		}

		try {
			return clientdao.update(id, client);

		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	
	public long delete(int id) throws ServiceException{
		
		try {
			return clientdao.delete(id);
		}catch(DaoException e ) {
			throw new ServiceException(e.getMessage());
		}
	}

	private void checkAge(Client client) throws ServiceException {
		long age = ChronoUnit.YEARS.between(client.getNaissance().toLocalDate(), LocalDate.now());
		if (age<18) {
			throw new ServiceException("le client doit avoir 18 ans");
		}
	}

	public Client findById(int id) throws ServiceException {

			Client c=clientdao.findById(id).get();
			return c;
	
		
	}

	public List<Client> findAll() throws ServiceException {
		try {
			return clientdao.findAll();
			
		}catch (DaoException e ) {
			throw new ServiceException(e.getMessage());
		}
		
	}
	
}
