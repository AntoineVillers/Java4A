package com.ensta.rentmanager.service;

import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.ensta.rentmanager.dao.ReservationDao;
import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.model.Reservation;

public class ReservationService {

	private ReservationDao resadao;
    private boolean test;
    
    public static ReservationService instance;
    public static ReservationService instanceTest = null;

    private ReservationService() {
        this.resadao = ReservationDao.getInstance(false);
    }
    
    private ReservationService(boolean test) {
		this.resadao = ReservationDao.getInstance(test);
		this.test = test;
	}
    

    public static ReservationService getInstance(boolean test) {
    	if(test){
			if(instanceTest == null) {
				instanceTest = new ReservationService(true);
			}
			return instanceTest;
		}else {
			if (instance == null) {
				instance = new ReservationService(false);

			}
			return instance;
		}
    }
	
	public Reservation findByid(int id) throws ServiceException {
		Reservation c;
		try {
			c = resadao.findByid(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
		return c;
	}
	
	public long create(Reservation resa) throws ServiceException {
		
		List<Reservation> reservationVehicule = this.findByVehicule(resa.getVehicle_id());

		long period = ChronoUnit.DAYS.between(resa.getDebut().toLocalDate(),
		        resa.getFin().toLocalDate());

		if (period <= 0) {
			throw new ServiceException("Dates non valides. ");
		}
		if (period > 7) {
			throw new ServiceException("Le Véhicule ne peut pas etre réservé pendant 7 jours");
		}
		for (int i = 0; i < reservationVehicule.size(); i++) {
			Date debut = reservationVehicule.get(i).getDebut();
			Date fin = reservationVehicule.get(i).getFin();
			if ((resa.getDebut().compareTo(debut) < 0) && (resa.getFin().compareTo(debut) > 0)) {
				throw new ServiceException("Véhicule déja réservé pendant ces dates. ");
			}
			else if ((resa.getDebut().compareTo(debut) > 0)
					&& (resa.getDebut().compareTo(fin) < 0)) {
				throw new ServiceException("Véhicule déja réservé pendant ces dates. ");
			}
		}
		try {
			return resadao.create(resa);
			
		} catch(DaoException e){
			throw new ServiceException(e.getMessage());
		}
		
	}

	public long update(int id, Reservation reservation) throws ServiceException {
		
		try {
			return resadao.update(id, reservation);

		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	public long delete(int id) throws ServiceException{
		try {
			return resadao.delete(id);
		}catch(DaoException e ) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	public List<Reservation> findAll() throws ServiceException {
		try {
			return resadao.findAll();
			
		}catch (DaoException e ) {
			throw new ServiceException(e.getMessage());
		}	
	}
	
	public List<Reservation> findByClient(int clientId) throws ServiceException {
		try {
			return resadao.findResaByClientId(clientId);
			
		}catch (DaoException e ) {
			throw new ServiceException(e.getMessage());
		}	
	}
	
	public List<Reservation> findByVehicule(int vehiculeId) throws ServiceException {
		try {
			return resadao.findResaByVehicleId(vehiculeId);
			
		}catch (DaoException e ) {
			throw new ServiceException(e.getMessage());
		}	
	}
	
	
	
	
}
