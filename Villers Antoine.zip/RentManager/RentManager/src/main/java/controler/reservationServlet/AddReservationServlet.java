package controler.reservationServlet;

import java.io.IOException;

import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Reservation;
import com.ensta.rentmanager.service.ClientService;
import com.ensta.rentmanager.service.ReservationService;
import com.ensta.rentmanager.service.VehicleService;

@WebServlet("/rents/create")
public class AddReservationServlet extends HttpServlet{
	
	ClientService clientService = ClientService.getInstance(false);
	ReservationService reservationService = ReservationService.getInstance(false);
	VehicleService vehicleService = VehicleService.getInstance(false);
			
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
		try {
			request.setAttribute("users", clientService.findAll());
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			request.setAttribute("vehicles", vehicleService.findAll());
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		int vehicle_id = Integer.parseInt(request.getParameter("car"));
		int client_id = Integer.parseInt(request.getParameter("client"));
		Date debut = Date.valueOf(request.getParameter("debut"));
		Date fin = Date.valueOf(request.getParameter("fin"));

		
		Reservation newreservation = new Reservation();
		newreservation.setVehicle_id(vehicle_id);
		newreservation.setClient_id(client_id);
		newreservation.setDebut(debut);
		newreservation.setFin(fin);
		
		RequestDispatcher dispatcher = null;

		try {
			reservationService.create(newreservation);
			response.sendRedirect(request.getContextPath() + "/rents");
		} catch (ServiceException e) {
			request.setAttribute("errorMessage", "erreur :" + e.getMessage());
			dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
			dispatcher.forward(request, response);
			//response.sendRedirect(request.getContextPath() + "/rents/create");
		}
	}
}
		