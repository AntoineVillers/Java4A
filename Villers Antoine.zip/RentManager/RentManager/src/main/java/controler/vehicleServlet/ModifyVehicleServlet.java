package controler.vehicleServlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Vehicle;
import com.ensta.rentmanager.service.VehicleService;

@WebServlet("/cars/modify")
public class ModifyVehicleServlet extends HttpServlet {
    private int vehicleId;

    VehicleService vehicleService = VehicleService.getInstance(false);

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/modify.jsp");

        vehicleId = Integer.parseInt(request.getParameter("id"));
        request.setAttribute("vehicleId", vehicleId);
        
            try {
            	Vehicle monVehicle = new Vehicle();
				monVehicle = vehicleService.findById(vehicleId);
				request.setAttribute("this_constructeur", monVehicle.getConstructeur());
				request.setAttribute("this_modele", monVehicle.getModele());
	            request.setAttribute("this_Nb_places", monVehicle.getNb_places());
			} catch (ServiceException | DaoException e) {
				request.setAttribute("errorMessage", "Une erreur est survenue. ");
	            dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/modify.jsp");
	            dispatcher.forward(request, response);
			}
            

        dispatcher.forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        vehicleId = Integer.parseInt(request.getParameter("id"));

    	Vehicle newVehicle = new Vehicle();
        newVehicle.setConstructeur(request.getParameter("constructeur"));
        newVehicle.setModele(request.getParameter("modele"));
        int Nb_places = Integer.parseInt(request.getParameter("Nb_places"));
        newVehicle.setNb_places(Nb_places);
        RequestDispatcher dispatcher;
        try {
            vehicleService.update(vehicleId, newVehicle);
            response.sendRedirect(request.getContextPath() + "/cars");
        } catch (ServiceException e) {
            request.setAttribute("errorMessage", "Une erreur est survenue . ");
            dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/modify.jsp");
            dispatcher.forward(request, response);
        }
    }
}