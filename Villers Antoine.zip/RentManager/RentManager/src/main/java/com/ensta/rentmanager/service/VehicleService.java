package com.ensta.rentmanager.service;

import java.util.List;

import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.model.Reservation;
import com.ensta.rentmanager.model.Vehicle;
import com.ensta.rentmanager.dao.ClientDao;
import com.ensta.rentmanager.dao.VehicleDao;

public class VehicleService {

	private VehicleDao vehicleDao;
	private boolean test;
	
	public static VehicleService instance;
	private static VehicleService instanceTest = null;

	
	private VehicleService() {
		this.vehicleDao = VehicleDao.getInstance(false);
	}
	
	private VehicleService(boolean test) {
		this.vehicleDao = VehicleDao.getInstance(test);
		this.test = test;
	}
	
	public static VehicleService getInstance(boolean test) {
		if(test){
			if(instanceTest == null) {
				instanceTest = new VehicleService(true);
			}
			return instanceTest;
		}else {
			if (instance == null) {
				instance = new VehicleService(false);

			}
			return instance;
		}
	}	
	
	public long create(Vehicle vehicle) throws ServiceException {
		
		if (vehicle.getNb_places() < 2) {
			throw new ServiceException("La voiture doit contenir au moins deux places.");
	    }
	    if (vehicle.getNb_places() > 9) {
			throw new ServiceException("La voiture doit contenir au max 9 places.");
	    }
		
		try {
			return vehicleDao.create(vehicle);
		
	} catch(DaoException e){
		throw new ServiceException(e.getMessage());
	}
	
	}
	
	public long update(int id, Vehicle vehicle) throws ServiceException {
		
		if (vehicle.getNb_places() < 2) {
			throw new ServiceException("La voiture doit contenir au moins deux places.");
	    }
	    if (vehicle.getNb_places() > 9) {
			throw new ServiceException("La voiture doit contenir au max 9 places.");
	    }
		
		try {
			return vehicleDao.update(id, vehicle);

		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	public long delete(int id) throws ServiceException{
		try {
			return vehicleDao.delete(id);
		}
		catch(DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	public Vehicle findById(int id) throws ServiceException, DaoException {				
					Vehicle v=vehicleDao.findById(id).get();
					return v;
				
		}		
				
	

	public List<Vehicle> findAll() throws ServiceException {
		try {
			
			return vehicleDao.findAll();
		}catch(DaoException e) {
			throw new ServiceException(e.getMessage());
		}
		
	}
	
}
