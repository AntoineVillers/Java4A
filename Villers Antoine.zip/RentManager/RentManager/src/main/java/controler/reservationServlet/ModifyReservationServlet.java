package controler.reservationServlet;

import java.io.IOException;

import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Reservation;
import com.ensta.rentmanager.service.ReservationService;

@WebServlet("/rents/modify")
public class ModifyReservationServlet extends HttpServlet {
    private int reservationId;

    ReservationService reservationService = ReservationService.getInstance(false);

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/modify.jsp");

        
		try {
			reservationId = Integer.parseInt(request.getParameter("id"));
	        request.setAttribute("reservationId", reservationId);
			Reservation maReservation = reservationService.findByid(reservationId);
			request.setAttribute("this_clientid", maReservation.getClient_id());
			request.setAttribute("this_vehicleid", maReservation.getVehicle_id());
			request.setAttribute("this_debut", maReservation.getDebut());
			request.setAttribute("this_fin", maReservation.getFin());
	        dispatcher.forward(request, response);
		} catch (ServiceException e) {
			request.setAttribute("errorMessage", "Une erreur est survenue. ");
            dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/modify.jsp");
            dispatcher.forward(request, response);
		}

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Reservation newReservation = new Reservation();
        reservationId = Integer.parseInt(request.getParameter("id"));
        int client_id = Integer.parseInt(request.getParameter("clientid"));
        newReservation.setClient_id(client_id);
        int vehicle_id = Integer.parseInt(request.getParameter("vehicleid"));
        newReservation.setVehicle_id(vehicle_id);
        newReservation.setDebut(Date.valueOf(request.getParameter("debut")));
        newReservation.setFin(Date.valueOf(request.getParameter("fin")));
        RequestDispatcher dispatcher;
        try {
            reservationService.update(reservationId, newReservation);
            response.sendRedirect(request.getContextPath() + "/rents");
        } catch (ServiceException e) {
            request.setAttribute("errorMessage", "Une erreur est survenue . ");
            dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/modify.jsp");
            dispatcher.forward(request, response);
        }
    }
}