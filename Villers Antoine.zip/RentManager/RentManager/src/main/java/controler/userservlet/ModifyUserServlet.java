package controler.userservlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.service.ClientService;

@WebServlet("/users/modify")
public class ModifyUserServlet extends HttpServlet {
    private int clientId;

    ClientService clientService = ClientService.getInstance(false);

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/modify.jsp");

        clientId = Integer.parseInt(request.getParameter("id"));
        request.setAttribute("clientId", clientId);
        Client monClient = new Client();

        try {
            monClient = clientService.findById(clientId);
            request.setAttribute("this_nom", monClient.getNom());
            request.setAttribute("this_prenom", monClient.getPrenom());
            request.setAttribute("this_email", monClient.getEmail());
            request.setAttribute("this_date_naissance", monClient.getNaissance());
        } catch (ServiceException e) {	
            request.setAttribute("errorMessage", "Une erreur est survenue. ");
            dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/modify.jsp");
            dispatcher.forward(request, response);
        }
        dispatcher.forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Client newClient = new Client();
        clientId = Integer.parseInt(request.getParameter("id"));
        newClient.setNom(request.getParameter("nom"));
        newClient.setPrenom(request.getParameter("prenom"));
        newClient.setEmail(request.getParameter("email"));
        newClient.setNaissance(Date.valueOf(request.getParameter("date_naissance")));
        RequestDispatcher dispatcher;
        try {
            clientService.update(clientId, newClient);
            response.sendRedirect(request.getContextPath() + "/users");
        } catch (ServiceException e) {
            request.setAttribute("errorMessage", "Une erreur est survenue . ");
            dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/modify.jsp");
            dispatcher.forward(request, response);
        }
    }
}