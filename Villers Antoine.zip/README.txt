Bonjour!

Lors de la première utilisation, pour initialiser la base de donnée, vous devez lancer le fichier "FillDatabase"
qui se trouve dans le dossier persistence.

Ensuite, à chaque utilisation, pour lancer le serveur, faites un click droit sur HomeServlet.java
dans le dossier controler et run as : run on server

Vous pouvez afficher la page dans le navigateur avec l'url : http://localhost:8080/RentManager/home.