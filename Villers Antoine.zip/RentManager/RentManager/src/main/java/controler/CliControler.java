package controler;

import java.sql.Date;

import java.util.List;
import java.util.Scanner;

import com.ensta.rentmanager.service.ClientService;
import com.ensta.rentmanager.service.ReservationService;
import com.ensta.rentmanager.service.VehicleService;
import com.ensta.rentmanager.model.*;
import com.ensta.rentmanager.exception.*; 

public class CliControler {
	private ClientService clientService= ClientService.getInstance(false);
	private VehicleService vehicleService= VehicleService.getInstance(false);
	private ReservationService resaService= ReservationService.getInstance(false);
	
	public static void main (String[] args){
		CliControler cli = new CliControler();
		Scanner sc=new Scanner(System.in);
		boolean done=false;
		
		while(!done) 
	{
			
			System.out.println("Liste des opérations");
			System.out.println("0- Quitter");
			System.out.println("1- Afficher la liste des clients");
			System.out.println("2- Ajouter un client");
			System.out.println("3- Supprimer un client");
			System.out.println("4- Trouver un client");
			System.out.println("5- Afficher la liste des véhicules");
			System.out.println("6- Ajouter un vehicule");
			System.out.println("7- Supprimer un véhicule");
			System.out.println("8- Trouver un vehicule");
			System.out.println("9- Créer une reservation");
			System.out.println("10- Supprimer une reservation");
			System.out.println("11- Trouver les reservations d'un client");
			System.out.println("12- Trouver les reservations d'un véhicule");
			System.out.println("13- Afficher toutes les reservations");
			
			int choix = sc.nextInt();
			sc.nextLine();
			
			switch(choix) {
			case 0:
				done = true;
				break;
			case 1:
				printAllClient(cli);			
				break;
			case 2:
				ajouterClient(cli, sc);
				break;
			case 3:
				supprimerClient(cli, sc);				
				break;
			case 4:
				clientByID(cli, sc);
				break;
			case 5:
				printAllVehicle(cli);				
				break;
			case 6:
				ajouterVehicule(cli, sc);
				break;
			case 7:
				supprimerVehicule(cli, sc);
				break;
			case 8:
				findVehicule(cli, sc);
				break;
			case 9:
				createResa(cli, sc);
				break;
			case 10:
				deleteReservation(cli, sc);
				break;
			case 11:
				findResaByClient(cli, sc);
				break;
			case 12:
				findResaByVehicule(cli, sc);
				break;
			case 13:
				printAllReservations(cli);
				break;
			default: 
				System.out.println("Pas le bon choix");
			}
		} sc.close();
	}


	private static void findResaByVehicule(CliControler cli, Scanner sc) {
		System.out.println("Trouver les reservations du vehicule n° :");
		int idv=sc.nextInt();
		try {
			List<Reservation>list= cli.resaService.findByVehicule(idv);
			
			for (Reservation resa : list) {
				System.out.println(resa);
			}
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void findResaByClient(CliControler cli, Scanner sc) {
		System.out.println("Trouver les reservations du client n° :");
		int idc=sc.nextInt();
		try {
		 	List<Reservation> list = cli.resaService.findByClient(idc);
		 	for(Reservation resa : list) {
		 		System.out.println(resa);
		 	}
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void deleteReservation(CliControler cli, Scanner sc) {
		System.out.println("Supprimer la n°");
		int id=sc.nextInt();
		try {
			cli.resaService.delete(id);
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void printAllReservations(CliControler cli) {
		try {
			List<Reservation> list = cli.resaService.findAll();
			
			for(Reservation resa : list) { 
				System.out.println(resa);
			}
			
		}catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}


	private static void createResa(CliControler cli, Scanner sc) {
		Reservation resa = new Reservation();
		System.out.println("Entrez l'id du client");
		resa.setClient_id(sc.nextInt());
		System.out.println("Entrez l'id du véhicule");
		resa.setVehicle_id(sc.nextInt());
		sc.nextLine();
		System.out.println("Entrez la date de début au format yyyy-[m]m-[d]d");
		resa.setDebut(Date.valueOf(sc.nextLine()));
		System.out.println("Entrez la date de fin au format yyyy-mm-dd");
		resa.setFin(Date.valueOf(sc.nextLine()));
		
		try {
			cli.resaService.create(resa);
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void findVehicule(CliControler cli, Scanner sc) {
		System.out.println("Trouver le véhicule dont l'id est:");
		try {
			int id=sc.nextInt();
			Vehicle v=cli.vehicleService.findById(id);
			System.out.println(v.toString());
		}catch(ServiceException | DaoException e)
		{
			e.printStackTrace();
		};
	}


	private static void supprimerVehicule(CliControler cli, Scanner sc) {
		System.out.println("Supprimer le véhicule n°");
		int id=sc.nextInt();
		try {
			cli.vehicleService.delete(id);
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void ajouterVehicule(CliControler cli, Scanner sc) {
		Vehicle v=new Vehicle();
		System.out.println("Entrez le constructeur");
		v.setConstructeur(sc.nextLine());
		System.out.println("Entrez le modele");
		v.setModele(sc.nextLine());
		System.out.println("Entrez le nombre de place");
		v.setNb_places(sc.nextInt());
		try {
			cli.vehicleService.create(v);
			
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void printAllVehicle(CliControler cli) {
		try {
			List<Vehicle> list = cli.vehicleService.findAll();
			
			for(Vehicle vehicle : list) { 
				System.out.println(vehicle);
			}
			
		}catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}


	private static void clientByID(CliControler cli, Scanner sc) {
		System.out.println("Trouver le client n°");
		try {
			int id=sc.nextInt();
			Client c=cli.clientService.findById(id);
			System.out.println(c.toString());
		}catch(ServiceException e)
		{
			e.printStackTrace();
		}
	}


	private static void supprimerClient(CliControler cli, Scanner sc) {
		System.out.println("Supprimer le client n° :");
		try {
			int id=sc.nextInt();
			cli.clientService.delete(id);
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}


	private static void ajouterClient(CliControler cli, Scanner sc) {
		Client client = new Client();
		System.out.println("Entrez le nom");
		client.setNom(sc.nextLine());
		System.out.println("Entrez le prénom");
		client.setPrenom(sc.nextLine());
		System.out.println("Entrez l'email");
		client.setEmail(sc.nextLine());
		System.out.println("Entrez la date de naissance au format yyyy-[m]m-[d]d");
		client.setNaissance(Date.valueOf(sc.nextLine()));	
		
		try {
			cli.clientService.create(client);
		}catch(ServiceException e) {
			e.printStackTrace();
		}
	}
		

	private static void printAllClient(CliControler cli) {
		try {
			List<Client> list = cli.clientService.findAll();
			
			for(Client client : list) { 
				System.out.println(client);
			}
			
		}catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
}
