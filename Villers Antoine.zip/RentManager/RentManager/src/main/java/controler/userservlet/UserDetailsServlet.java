package controler.userservlet;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ensta.rentmanager.exception.DaoException;
import com.ensta.rentmanager.exception.ServiceException;
import com.ensta.rentmanager.model.Client;
import com.ensta.rentmanager.model.Reservation;
import com.ensta.rentmanager.model.Vehicle;
import com.ensta.rentmanager.service.ClientService;
import com.ensta.rentmanager.service.ReservationService;
import com.ensta.rentmanager.service.VehicleService;

@WebServlet("/users/details")
public class UserDetailsServlet extends HttpServlet{
	
	ReservationService reservationService = ReservationService.getInstance(false);
	VehicleService vehicleService = VehicleService.getInstance(false);
	
	ClientService clientService = ClientService.getInstance(false);
			
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/details.jsp"); 
		
		Client test = new Client();
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			test = clientService.findById(id);
			request.setAttribute("client", test);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		try {
			int vehicleId = Integer.parseInt(request.getParameter("id"));	
			List<Vehicle> ListVehicle = new ArrayList<Vehicle>();
			Vehicle Vehicle = vehicleService.findById(vehicleId);
			ListVehicle.add(Vehicle);
			request.setAttribute("ListVehicle", ListVehicle);
		} catch (ServiceException | DaoException e) {
			request.setAttribute("errorMessage", "erreur :" + e.getMessage());
		}
		try{
			int clientId = Integer.parseInt(request.getParameter("id"));
			List<Reservation> ListReservation = reservationService.findByClient(clientId);
			request.setAttribute("ListReservation", ListReservation);
		} catch (ServiceException e1) {
			request.setAttribute("errorMessage", "erreur :" + e1.getMessage());
		}
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doGet(request, response);
		
	}
}